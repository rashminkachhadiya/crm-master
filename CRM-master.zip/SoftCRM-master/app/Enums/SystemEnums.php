<?php

namespace App\Enums;

class SystemEnums
{
    const currency = 'currency';
    const middleWareAuth = 'auth';
}
