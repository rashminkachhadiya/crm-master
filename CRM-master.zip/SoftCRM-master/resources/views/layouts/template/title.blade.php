<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h4 class="page-header">
                    @yield('caption')
                    <br>
                    <small>@yield('lyric')</small>
                </h4>
            </div>
        </div>
    </div>